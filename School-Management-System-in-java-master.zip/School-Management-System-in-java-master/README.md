# School Management System using Java

The School Management System in Java is an application developed for schools. 
It is an application developed in Java which is used to store all the school-related records.
It stores information related to students, staff, and teachers. The database used is MS-Access.
The objective of developing such a system was to reduce the errors that creep in the manual system where it was very difficult to store the records.
It also provides the facility to calculate the attendance of the student. There are four types of login for this system the administrator login.
The whole system is handled by the administrator who has all the rights to edit or modify any school member information. 
The student can view the details by logging with their details.
This system was developed to provide a secure, easy to use a reliable system. This was created to handle all the school-related information and save it in records.

# School Management System Modules:
Registration module: In this module, the users of the system have to register themselves with all their personal details and after that, they can log in to the system
Login module: This module page allows login for admin.
Add module: This allows to add new users to the system database.
Save module: This allows to save the records in a database.
Delete module: It deleted the student records from a database.
View profile module: This module displays information according to the type of user. The admin can view all the details while the other users can only view their own details.
Attendance module: This module allows to calculate the attendance of the student and display it.

<b>Language Used</b>
 Java
