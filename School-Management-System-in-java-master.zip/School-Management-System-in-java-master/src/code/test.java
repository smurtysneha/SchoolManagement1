/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package code;

import javax.swing.JComboBox;

/**
 *
 * @author Mithrandir
 */
public class test {
    public static void main(String[] args) {
        Finance a=new Finance();
      //  a.dataToStudentFinaceAdd();
     //   a.getYear();
     //   a.getMonth();
   //     System.out.println(a.getMonthString());
//       a.FeedFees();
//        System.err.println( a.generateDues("1"));
   //     a.updateDuesStudent("3",20);
     //   a.dataToStudentFinaceAdd();
      //  System.out.println(a.getDues(3));
//        a.payFees(6, 30);
        Staff st=new Staff();
//        System.out.println(st.getMonthint("January"));
//a.setStationaryFee(500);
//a.setregistrationFee(1, 5000);
//           a.addFinance();
      //   a.dataToStudentFinaceAdd();
           Student st1=new Student();
         //  st1.StudentTotaskTable();
      //     a.getstationaryfee(1);
      //  a.extrapay02(1);
//      a.updateTask01(1, "90", "2600");
//a.updateTask01("90", "666");
//TeacherSalary sal=new TeacherSalary();
//sal.SalaryAfterIncreament(1);
//System.out.println("--------------------------------------------------------------");
//System.out.println(sal.getAbsents(1));;
//        System.out.println(st.getAbsents(1));
//sal.SalaryAfterIncreament(1);
//System.out.println("sal");

//System.out.println(a.getMonthString(1));
//        System.out.println(sal.calculateabsentSalary(18000, 0));
//st.attendancePresent1("1");
//st.staffToAttendance();
//System.out.println(st.getTotalRetention(1));
//st.staffTosalary();
//classes c=new classes();
//        JComboBox classtf1=new JComboBox();
//        JComboBox sectf1=new JComboBox();
//c.Fillcombo(classtf1, sectf1);
//System.out.println(st.getTotalDUES(1));
//a.getsalaryDuestotal();
//AdminLogin l=new AdminLogin();
//        System.out.println(l.allow());
//System.out.println(a.currentins01(4));
//a.adddueDate();
//System.out.println(1/0);
     // a.FeedFees();
Student i=new Student();
//st.updateSalaryDues("1","6","2018");
System.out.println(a.getextra01(2));
System.out.println(a.generateDues("2"));
//        System.out.println(i.currentins01(1));
//st.updatebasicsalary("2", "99");
//a.reUpdaterues("2");
//a.updatedues(50,"9", "8","2018");
//a.updateDuesStudentFinancefees("2", 0,"11","2018");
//a.FeedFees();
    }
}
